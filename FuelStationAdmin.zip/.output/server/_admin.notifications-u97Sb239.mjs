import { i as __toESM } from "./_runtime.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { c as formatDateTime, l as formatNumber, m as useAdmin } from "./_ssr/admin-store-DLYihnwj.mjs";
import { t as cn } from "./_ssr/utils-C_uf36nf.mjs";
import { g as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { I as Bell, L as BellRing, N as CheckCheck, c as Tags, i as UserPlus, n as Wrench } from "./_libs/lucide-react.mjs";
import { i as StatCard, n as PageHeader, r as Panel } from "./_ssr/primitives-BY6eLzWO.mjs";
import { t as Button } from "./_ssr/button-Bq5vK6RO.mjs";
import { n as toast } from "./_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_admin.notifications-u97Sb239.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var icons = {
	registration: UserPlus,
	group: Tags,
	worker: Wrench,
	system: Bell
};
var filters = [
	{
		key: "all",
		label: "All"
	},
	{
		key: "unread",
		label: "Unread"
	},
	{
		key: "registration",
		label: "Registrations"
	},
	{
		key: "system",
		label: "System"
	}
];
function NotificationsPage() {
	const { notifications, unreadCount, markRead, markAllRead, customers } = useAdmin();
	const [filter, setFilter] = (0, import_react.useState)("all");
	const list = notifications.filter((n) => filter === "all" ? true : filter === "unread" ? !n.read : n.type === filter);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Notifications",
			subtitle: "Everything that needs an admin decision, in one place.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				onClick: () => {
					markAllRead();
					toast.success("All notifications marked as read");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckCheck, { className: "size-4" }), " Mark all read"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 gap-4 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Total notifications",
					value: formatNumber(notifications.length),
					icon: Bell
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Unread",
					value: formatNumber(unreadCount),
					icon: BellRing,
					tone: "warning"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Registrations pending group",
					value: formatNumber(customers.filter((c) => c.groupId === "grp-default").length),
					icon: UserPlus,
					tone: "teal"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			title: "Notification centre",
			description: "Newest first",
			className: "mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 flex flex-wrap items-center gap-1 rounded-lg border border-border bg-card p-1",
				children: filters.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setFilter(f.key),
					className: filter === f.key ? "rounded-md bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground" : "rounded-md px-3 py-1.5 text-xs font-medium text-muted-foreground hover:bg-muted",
					children: f.label
				}, f.key))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "divide-y divide-border",
				children: [list.map((n) => {
					const Icon = icons[n.type];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: cn("flex flex-wrap items-start gap-3 px-1 py-4", !n.read && "bg-accent/40"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("flex size-9 shrink-0 items-center justify-center rounded-lg", n.read ? "bg-muted text-muted-foreground" : "bg-primary/12 text-primary"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-[18px]" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-56 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-semibold text-foreground",
											children: n.title
										}), !n.read && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-primary" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-0.5 text-sm text-muted-foreground",
										children: n.message
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-xs text-muted-foreground",
										children: formatDateTime(n.createdAt)
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [n.customerId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									size: "sm",
									variant: "outline",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/customers",
										children: "Open customer"
									})
								}), !n.read && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => markRead(n.id),
									children: "Mark read"
								})]
							})
						]
					}, n.id);
				}), list.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "py-12 text-center text-sm text-muted-foreground",
					children: "Nothing here — you're all caught up."
				})]
			})]
		})
	] });
}
//#endregion
export { NotificationsPage as component };
