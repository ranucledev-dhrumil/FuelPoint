import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { a as YAxis, c as Line, d as Pie, f as LabelList, g as Legend, h as Tooltip, i as LineChart, l as CartesianGrid, m as ResponsiveContainer, n as PieChart, o as XAxis, p as Cell, r as BarChart, s as Area, t as AreaChart, u as Bar } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/charts-CYjSJrBW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var axis = {
	stroke: "var(--muted-foreground)",
	fontSize: 11,
	tickLine: false,
	axisLine: false
};
var tooltipStyle = { contentStyle: {
	borderRadius: 12,
	border: "1px solid var(--border)",
	background: "var(--card)",
	fontSize: 12,
	boxShadow: "var(--shadow-card)"
} };
/** Charts render only after mount so SSR output and client stay in sync. */
function ChartFrame({ height, children }) {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	if (!mounted) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		style: { height },
		className: "animate-pulse rounded-lg bg-muted/60"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		style: { height },
		className: "w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children
		})
	});
}
function TrendAreaChart({ data, dataKey, color = "var(--primary)", height = 280, valueFormatter }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartFrame, {
		height,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
			data,
			margin: {
				top: 8,
				right: 12,
				left: 0,
				bottom: 0
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
					id: `grad-${dataKey}`,
					x1: "0",
					y1: "0",
					x2: "0",
					y2: "1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
						offset: "0%",
						stopColor: color,
						stopOpacity: .35
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
						offset: "100%",
						stopColor: color,
						stopOpacity: .02
					})]
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
					strokeDasharray: "3 3",
					stroke: "var(--border)",
					vertical: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
					dataKey: "label",
					...axis,
					interval: "preserveStartEnd",
					minTickGap: 24
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
					...axis,
					width: 48
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
					...tooltipStyle,
					formatter: (v) => valueFormatter ? valueFormatter(v) : v
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
					type: "monotone",
					dataKey,
					stroke: color,
					strokeWidth: 2,
					fill: `url(#grad-${dataKey})`
				})
			]
		})
	});
}
function MultiLineChart({ data, series, height = 280 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartFrame, {
		height,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
			data,
			margin: {
				top: 8,
				right: 12,
				left: 0,
				bottom: 0
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
					strokeDasharray: "3 3",
					stroke: "var(--border)",
					vertical: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
					dataKey: "label",
					...axis,
					interval: "preserveStartEnd",
					minTickGap: 24
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
					...axis,
					width: 48
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { ...tooltipStyle }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
					iconType: "circle",
					wrapperStyle: {
						fontSize: 12,
						paddingTop: 4
					}
				}),
				series.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
					type: "monotone",
					dataKey: s.key,
					name: s.name,
					stroke: s.color,
					strokeWidth: 2,
					dot: false
				}, s.key))
			]
		})
	});
}
function HorizontalBarChart({ data, dataKey, categoryKey = "name", color = "var(--teal)", height = 300, valueFormatter, yAxisWidth = 85, showLabels = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartFrame, {
		height,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
			data,
			layout: "vertical",
			margin: {
				top: 8,
				right: showLabels ? 64 : 16,
				left: 4,
				bottom: 4
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
					strokeDasharray: "3 3",
					stroke: "var(--border)",
					horizontal: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
					type: "number",
					...axis,
					tickFormatter: (v) => {
						if (!valueFormatter) return v.toLocaleString("en-IN");
						if (v >= 1e5) return `₹${(v / 1e5).toFixed(1)}L`;
						if (v >= 1e3) return `₹${(v / 1e3).toFixed(0)}k`;
						return `₹${v}`;
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
					type: "category",
					dataKey: categoryKey,
					...axis,
					width: yAxisWidth
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
					...tooltipStyle,
					formatter: (v) => [valueFormatter ? valueFormatter(v) : v.toLocaleString("en-IN"), ""]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
					dataKey,
					fill: color,
					radius: [
						0,
						6,
						6,
						0
					],
					barSize: 16,
					children: showLabels && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabelList, {
						dataKey,
						position: "right",
						formatter: (v) => valueFormatter ? valueFormatter(v) : v.toLocaleString("en-IN"),
						style: {
							fontSize: 11,
							fontWeight: 600,
							fill: "var(--foreground)"
						}
					})
				})
			]
		})
	});
}
var donutColors = [
	"var(--chart-1)",
	"var(--chart-2)",
	"var(--chart-3)",
	"var(--chart-4)",
	"var(--chart-5)",
	"var(--muted-foreground)"
];
function DonutChart({ data, dataKey = "value", height = 280, valueFormatter }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartFrame, {
		height,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, {
			margin: {
				top: 8,
				right: 8,
				bottom: 8,
				left: 8
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
					data,
					dataKey,
					nameKey: "name",
					cx: "50%",
					cy: "44%",
					innerRadius: "52%",
					outerRadius: "78%",
					paddingAngle: 3,
					stroke: "var(--card)",
					strokeWidth: 2,
					children: data.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: donutColors[i % donutColors.length] }, i))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
					...tooltipStyle,
					formatter: (v) => valueFormatter ? valueFormatter(v) : v
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
					iconType: "circle",
					layout: "horizontal",
					verticalAlign: "bottom",
					align: "center",
					wrapperStyle: {
						fontSize: 12,
						paddingTop: 8
					}
				})
			]
		})
	});
}
//#endregion
export { TrendAreaChart as i, HorizontalBarChart as n, MultiLineChart as r, DonutChart as t };
