import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { A as ChevronLeft, D as ChevronsUpDown, k as ChevronRight } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/DataTable-C6ZgHd1t.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TablePagination({ currentPage, totalPages, pageSize, totalItems, currentCount, onPageChange, className }) {
	const safePage = Math.max(1, Math.min(currentPage, Math.max(1, totalPages)));
	const from = currentCount > 0 ? (safePage - 1) * pageSize + 1 : 0;
	const to = (safePage - 1) * pageSize + currentCount;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex flex-wrap items-center justify-between gap-3 border-t border-border px-1 pt-4 text-sm", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs text-muted-foreground",
			children: [
				"Showing ",
				from,
				"–",
				to,
				" of ",
				totalItems
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onPageChange(Math.max(1, safePage - 1)),
					disabled: safePage <= 1,
					className: "inline-flex items-center gap-1 rounded-md border border-border px-2.5 py-1.5 text-xs font-medium transition-colors hover:bg-muted disabled:cursor-not-allowed disabled:opacity-40",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-3.5" }), " Prev"]
				}),
				Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
					const start = Math.max(1, Math.min(safePage - 2, totalPages - 4));
					const num = totalPages <= 5 ? i + 1 : start + i;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onPageChange(num),
						className: cn("size-8 rounded-md border text-xs font-medium transition-colors", num === safePage ? "border-primary bg-primary text-primary-foreground" : "border-border hover:bg-muted"),
						children: num
					}, num);
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onPageChange(Math.min(totalPages, safePage + 1)),
					disabled: safePage >= totalPages,
					className: "inline-flex items-center gap-1 rounded-md border border-border px-2.5 py-1.5 text-xs font-medium transition-colors hover:bg-muted disabled:cursor-not-allowed disabled:opacity-40",
					children: ["Next ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-3.5" })]
				})
			]
		})]
	});
}
function DataTable({ rows, columns, pageSize = 8, emptyMessage = "No records match the current filters.", onRowClick }) {
	const [sort, setSort] = (0, import_react.useState)(null);
	const [page, setPage] = (0, import_react.useState)(1);
	(0, import_react.useEffect)(() => setPage(1), [rows.length, sort]);
	const sorted = (0, import_react.useMemo)(() => {
		if (!sort) return rows;
		const col = columns.find((c) => c.key === sort.key);
		if (!col?.sortValue) return rows;
		return [...rows].sort((a, b) => {
			const av = col.sortValue(a);
			const bv = col.sortValue(b);
			const res = typeof av === "number" && typeof bv === "number" ? av - bv : String(av).localeCompare(String(bv));
			return sort.dir === "asc" ? res : -res;
		});
	}, [
		rows,
		sort,
		columns
	]);
	const totalPages = Math.max(1, Math.ceil(sorted.length / pageSize));
	const safePage = Math.min(page, totalPages);
	const slice = sorted.slice((safePage - 1) * pageSize, safePage * pageSize);
	const toggleSort = (key) => setSort((prev) => prev?.key === key ? {
		key,
		dir: prev.dir === "asc" ? "desc" : "asc"
	} : {
		key,
		dir: "desc"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full min-w-[720px] border-collapse text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
				className: "border-b border-border bg-muted/50",
				children: columns.map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: cn("px-4 py-3 text-left text-xs font-semibold tracking-wide text-muted-foreground uppercase", col.align === "right" && "text-right"),
					children: col.sortValue ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => toggleSort(col.key),
						className: cn("inline-flex items-center gap-1 transition-colors hover:text-foreground", sort?.key === col.key && "text-primary"),
						children: [col.header, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsUpDown, { className: "size-3" })]
					}) : col.header
				}, col.key))
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [slice.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				colSpan: columns.length,
				className: "px-4 py-12 text-center text-sm text-muted-foreground",
				children: emptyMessage
			}) }), slice.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
				onClick: () => onRowClick?.(row),
				className: cn("border-b border-border/70 last:border-0", onRowClick && "cursor-pointer transition-colors hover:bg-accent/60"),
				children: columns.map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: cn("px-4 py-3 align-middle text-foreground", col.align === "right" && "text-right", col.className),
					children: col.render(row)
				}, col.key))
			}, row.id))] })]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TablePagination, {
		currentPage: safePage,
		totalPages,
		pageSize,
		totalItems: sorted.length,
		currentCount: slice.length,
		onPageChange: setPage
	})] });
}
//#endregion
export { TablePagination as n, DataTable as t };
