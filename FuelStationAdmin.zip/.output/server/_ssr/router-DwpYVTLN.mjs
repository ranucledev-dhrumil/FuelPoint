import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as AdminProvider } from "./admin-store-DLYihnwj.mjs";
import { c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, m as createFileRoute, p as lazyRouteComponent, s as Scripts, v as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { t as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DwpYVTLN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-Bo44Ngd_.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$9 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "FuelPoint Admin Console" },
			{
				name: "description",
				content: "Admin console for petrol pump customer, worker, group and discount management."
			},
			{
				property: "og:title",
				content: "FuelPoint Admin Console"
			},
			{
				property: "og:description",
				content: "Admin console for petrol pump customer, worker, group and discount management."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap"
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				type: "image/x-icon"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$9.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {})] })
	});
}
var $$splitComponentImporter$8 = () => import("./routes-BCMLRMZ5.mjs");
var Route$8 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "Admin Sign In — FuelPoint Console" },
		{
			name: "description",
			content: "Secure sign in for petrol pump administrators managing customers, workers and discount groups."
		},
		{
			property: "og:title",
			content: "Admin Sign In — FuelPoint Console"
		},
		{
			property: "og:description",
			content: "Secure sign in for the FuelPoint petrol pump admin console."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("../_admin-OS1Bg1k-.mjs");
var Route$7 = createFileRoute("/_admin")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("../_admin.customers-C1aZJbX0.mjs");
var Route$6 = createFileRoute("/_admin/customers")({
	head: () => ({ meta: [
		{ title: "Customers — FuelPoint Admin" },
		{
			name: "description",
			content: "Manage registered customers, assign discount groups and review fuelling activity."
		},
		{
			property: "og:title",
			content: "Customers — FuelPoint Admin"
		},
		{
			property: "og:description",
			content: "Customer registrations, group assignment and discount received."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("../_admin.dashboard-D7bDI13R.mjs");
var Route$5 = createFileRoute("/_admin/dashboard")({
	head: () => ({ meta: [
		{ title: "Dashboard — FuelPoint Admin" },
		{
			name: "description",
			content: "Live analytics for scans, discounts, customer registrations and worker activity."
		},
		{
			property: "og:title",
			content: "Dashboard — FuelPoint Admin"
		},
		{
			property: "og:description",
			content: "Live petrol pump analytics: scans, discounts, registrations and workers."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("../_admin.groups-CQdSa4h6.mjs");
var Route$4 = createFileRoute("/_admin/groups")({
	head: () => ({ meta: [
		{ title: "Groups & Discounts — FuelPoint Admin" },
		{
			name: "description",
			content: "Create discount groups, set percentages and assign customers to Family, Friends, Employees and more."
		},
		{
			property: "og:title",
			content: "Groups & Discounts — FuelPoint Admin"
		},
		{
			property: "og:description",
			content: "Manage dynamic discount groups and customer assignments."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("../_admin.notifications-u97Sb239.mjs");
var Route$3 = createFileRoute("/_admin/notifications")({
	head: () => ({ meta: [
		{ title: "Notifications — FuelPoint Admin" },
		{
			name: "description",
			content: "Admin notification centre: new customer registrations awaiting group assignment and system alerts."
		},
		{
			property: "og:title",
			content: "Notifications — FuelPoint Admin"
		},
		{
			property: "og:description",
			content: "Registrations awaiting group assignment, worker alerts and system updates."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("../_admin.profile-8uHjpV8l.mjs");
var Route$2 = createFileRoute("/_admin/profile")({
	head: () => ({ meta: [
		{ title: "My Profile — FuelPoint Admin" },
		{
			name: "description",
			content: "Manage your admin account details, contact information and password."
		},
		{
			property: "og:title",
			content: "My Profile — FuelPoint Admin"
		},
		{
			property: "og:description",
			content: "Admin account details, contact information and password settings."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("../_admin.reports-BKQEyupj.mjs");
var Route$1 = createFileRoute("/_admin/reports")({
	head: () => ({ meta: [
		{ title: "Reports — FuelPoint Admin" },
		{
			name: "description",
			content: "Customer, worker, transaction, discount and group reports with date ranges and CSV export."
		},
		{
			property: "og:title",
			content: "Reports — FuelPoint Admin"
		},
		{
			property: "og:description",
			content: "Date-ranged petrol pump reports with summary metrics and CSV export."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("../_admin.workers-203z4DCK.mjs");
var Route = createFileRoute("/_admin/workers")({
	head: () => ({ meta: [
		{ title: "Workers — FuelPoint Admin" },
		{
			name: "description",
			content: "Manage pump workers, monitor scans, transactions handled and discount processed."
		},
		{
			property: "og:title",
			content: "Workers — FuelPoint Admin"
		},
		{
			property: "og:description",
			content: "Worker performance: scans, customers scanned and discount processed."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$8.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$9
});
var AdminRoute = Route$7.update({
	id: "/_admin",
	getParentRoute: () => Route$9
});
var AdminRouteChildren = {
	AdminCustomersRoute: Route$6.update({
		id: "/customers",
		path: "/customers",
		getParentRoute: () => AdminRoute
	}),
	AdminDashboardRoute: Route$5.update({
		id: "/dashboard",
		path: "/dashboard",
		getParentRoute: () => AdminRoute
	}),
	AdminGroupsRoute: Route$4.update({
		id: "/groups",
		path: "/groups",
		getParentRoute: () => AdminRoute
	}),
	AdminNotificationsRoute: Route$3.update({
		id: "/notifications",
		path: "/notifications",
		getParentRoute: () => AdminRoute
	}),
	AdminProfileRoute: Route$2.update({
		id: "/profile",
		path: "/profile",
		getParentRoute: () => AdminRoute
	}),
	AdminReportsRoute: Route$1.update({
		id: "/reports",
		path: "/reports",
		getParentRoute: () => AdminRoute
	}),
	AdminWorkersRoute: Route.update({
		id: "/workers",
		path: "/workers",
		getParentRoute: () => AdminRoute
	})
};
var rootRouteChildren = {
	IndexRoute,
	AdminRoute: AdminRoute._addFileChildren(AdminRouteChildren)
};
var routeTree = Route$9._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
