import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-store-DLYihnwj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Deterministic mock data. Everything here is replaceable by real API calls —
* see src/services/adminService.ts for the single access layer.
*/
function rng(seed) {
	let s = seed;
	return () => {
		s = (s * 1664525 + 1013904223) % 4294967296;
		return s / 4294967296;
	};
}
var rand = rng(20260923);
var pick = (arr) => arr[Math.floor(rand() * arr.length)];
var between = (min, max) => Math.floor(rand() * (max - min + 1)) + min;
/** Fixed "today" keeps mock data stable across renders. */
var TODAY = /* @__PURE__ */ new Date("2026-09-23T10:00:00.000Z");
var dayMs = 864e5;
var iso = (daysAgo, hour = 9, minute = 15) => {
	const d = /* @__PURE__ */ new Date(TODAY.getTime() - daysAgo * dayMs);
	d.setUTCHours(hour, minute, 0, 0);
	return d.toISOString();
};
var groups = [
	{
		id: "grp-default",
		name: "Default / Unassigned",
		discountPercent: 0,
		description: "New registrations land here until an admin assigns a group.",
		active: true,
		createdAt: iso(400),
		isDefault: true
	},
	{
		id: "grp-family",
		name: "Family",
		discountPercent: 2,
		description: "Owner family members and relatives.",
		active: true,
		createdAt: iso(360)
	},
	{
		id: "grp-friends",
		name: "Friends",
		discountPercent: 1,
		description: "Close friends and long-standing personal contacts.",
		active: true,
		createdAt: iso(352)
	},
	{
		id: "grp-employees",
		name: "Employees",
		discountPercent: 3,
		description: "Staff of the pump and partner businesses.",
		active: true,
		createdAt: iso(340)
	},
	{
		id: "grp-fleet",
		name: "Fleet Partners",
		discountPercent: 2.5,
		description: "Contracted logistics and taxi fleets.",
		active: true,
		createdAt: iso(120)
	},
	{
		id: "grp-legacy",
		name: "Festive 2025",
		discountPercent: 1.5,
		description: "Seasonal campaign group, currently paused.",
		active: false,
		createdAt: iso(300)
	}
];
var firstNames = [
	"Aarav",
	"Vivaan",
	"Diya",
	"Ananya",
	"Kabir",
	"Meera",
	"Rohan",
	"Ishita",
	"Arjun",
	"Nisha",
	"Farhan",
	"Sana",
	"Vikram",
	"Priya",
	"Dev",
	"Tara",
	"Imran",
	"Kavya",
	"Rahul",
	"Neha",
	"Yash",
	"Simran",
	"Aditya",
	"Pooja",
	"Manav",
	"Ritika",
	"Zoya",
	"Karan",
	"Lata",
	"Omar"
];
var lastNames = [
	"Sharma",
	"Patel",
	"Nair",
	"Iyer",
	"Khan",
	"Reddy",
	"Gupta",
	"Menon",
	"Bose",
	"Chopra",
	"Desai",
	"Joshi",
	"Rao",
	"Verma",
	"Sethi",
	"Kulkarni",
	"Bhat",
	"Mehta"
];
var vehicles = [
	"Maruti Swift",
	"Hyundai Creta",
	"Honda City",
	"Tata Nexon",
	"Royal Enfield 350",
	"Toyota Innova",
	"Mahindra Thar",
	"TVS Jupiter",
	"Kia Seltos",
	"Ashok Leyland Truck"
];
var weightedGroup = () => {
	const r = rand();
	if (r < .14) return "grp-default";
	if (r < .4) return "grp-family";
	if (r < .62) return "grp-friends";
	if (r < .82) return "grp-employees";
	if (r < .95) return "grp-fleet";
	return "grp-legacy";
};
var workers = [
	"Suresh Kumar",
	"Anita Deshmukh",
	"Ravi Shankar",
	"Pooja Bansal",
	"Imtiaz Ali",
	"Deepak Yadav",
	"Sneha Kulkarni",
	"Manoj Pillai",
	"Farida Sheikh",
	"Naveen Rathore"
].map((name, i) => {
	const scans = between(120, 1450);
	const status = i === 8 ? "suspended" : i % 3 === 2 ? "offline" : "active";
	return {
		id: `WRK-${String(i + 1).padStart(3, "0")}`,
		name,
		email: `${name.toLowerCase().replace(/\s+/g, ".")}@fuelpoint.in`,
		phone: `+91 9${between(1e8, 899999999)}`,
		shift: [
			"Morning",
			"Evening",
			"Night"
		][i % 3],
		status,
		joinedAt: iso(between(60, 700)),
		scans,
		customersScanned: Math.round(scans * (.55 + rand() * .3)),
		transactions: Math.round(scans * (.8 + rand() * .18)),
		discountProcessed: Math.round(scans * between(9, 26)),
		lastActivity: iso(status === "active" ? 0 : between(1, 14), between(7, 21), between(0, 59))
	};
});
var customers = Array.from({ length: 96 }, (_, i) => {
	const name = `${pick(firstNames)} ${pick(lastNames)}`;
	const groupId = weightedGroup();
	const registeredDaysAgo = between(0, 320);
	const transactions = registeredDaysAgo < 3 ? between(0, 2) : between(1, 68);
	const group = groups.find((g) => g.id === groupId);
	const totalSpend = transactions * between(700, 3200);
	const status = groupId === "grp-default" && registeredDaysAgo < 6 ? "pending" : transactions === 0 || registeredDaysAgo > 250 ? "inactive" : "active";
	return {
		id: `CUS-${String(1e3 + i)}`,
		name,
		phone: `+91 8${between(1e8, 899999999)}`,
		email: `${name.toLowerCase().replace(/\s+/g, ".")}${i}@mail.com`,
		vehicle: pick(vehicles),
		groupId,
		registeredAt: iso(registeredDaysAgo, between(8, 20), between(0, 59)),
		lastActivity: transactions === 0 ? null : iso(between(0, 40), between(7, 22), between(0, 59)),
		transactions,
		totalSpend,
		discountReceived: Math.round(totalSpend * group.discountPercent / 100),
		status
	};
});
var fuels = [
	"Petrol",
	"Diesel",
	"CNG"
];
var transactions = Array.from({ length: 420 }, (_, i) => {
	const customer = pick(customers.filter((c) => c.transactions > 0));
	const worker = pick(workers);
	const group = groups.find((g) => g.id === customer.groupId);
	const amount = between(450, 4800);
	const daysAgo = between(0, 89);
	return {
		id: `TXN-${String(9e4 + i)}`,
		customerId: customer.id,
		customerName: customer.name,
		workerId: worker.id,
		workerName: worker.name,
		groupId: group.id,
		amount,
		discountPercent: group.discountPercent,
		discountAmount: Math.round(amount * group.discountPercent / 100),
		litres: Math.round(amount / 104 * 10) / 10,
		fuel: pick([...fuels]),
		createdAt: iso(daysAgo, between(6, 23), between(0, 59))
	};
}).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
var notifications = [...[
	...[...customers].sort((a, b) => b.registeredAt.localeCompare(a.registeredAt)).slice(0, 6).map((c, i) => ({
		id: `NTF-R${i}`,
		type: "registration",
		title: "New customer registration — group assignment required",
		message: `${c.name} (${c.phone}) registered and is currently in Default / Unassigned.`,
		createdAt: c.registeredAt,
		read: i > 3,
		customerId: c.id
	})),
	{
		id: "NTF-W1",
		type: "worker",
		title: "Worker account suspended",
		message: "Farida Sheikh was suspended after repeated scan mismatches.",
		createdAt: iso(2, 11, 30),
		read: false
	},
	{
		id: "NTF-G1",
		type: "group",
		title: "Discount updated",
		message: "Fleet Partners discount changed from 2% to 2.5%.",
		createdAt: iso(4, 16, 10),
		read: true
	},
	{
		id: "NTF-S1",
		type: "system",
		title: "Monthly discount report ready",
		message: "August discount reconciliation is available in Reports.",
		createdAt: iso(6, 8, 5),
		read: true
	}
]].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
var adminProfile = {
	name: "Rajesh Menon",
	email: "rajesh.menon@fuelpoint.in",
	phone: "+91 98204 41120",
	role: "Super Admin",
	location: "Pune, Maharashtra",
	joinedAt: iso(720),
	initials: "RM"
};
/**
* Single access layer for admin data. Swap the bodies of these functions for
* real HTTP calls (fetch/axios) later — the UI only talks to this module.
*/
var adminService = {
	getGroups: () => groups,
	getCustomers: () => customers,
	getWorkers: () => workers,
	getTransactions: () => transactions,
	getNotifications: () => notifications,
	getProfile: () => adminProfile,
	getToday: () => TODAY
};
var DEFAULT_GROUP_ID = "grp-default";
var formatCurrency = (value) => `₹${Math.round(value).toLocaleString("en-IN")}`;
var formatNumber = (value) => value.toLocaleString("en-IN");
var formatDate = (value) => value ? new Date(value).toLocaleDateString("en-IN", {
	day: "2-digit",
	month: "short",
	year: "numeric"
}) : "—";
var formatDateTime = (value) => value ? new Date(value).toLocaleString("en-IN", {
	day: "2-digit",
	month: "short",
	hour: "2-digit",
	minute: "2-digit"
}) : "—";
var relativeDays = (value) => {
	if (!value) return "Never";
	const diff = Math.floor((TODAY.getTime() - new Date(value).getTime()) / 864e5);
	if (diff <= 0) return "Today";
	if (diff === 1) return "Yesterday";
	if (diff < 30) return `${diff} days ago`;
	return `${Math.floor(diff / 30)} mo ago`;
};
var dayKey = (value) => value.slice(0, 10);
var todayKey = () => TODAY.toISOString().slice(0, 10);
function buildOverview(customers, workers, groups, transactions) {
	const tk = todayKey();
	const totalDiscount = transactions.reduce((s, t) => s + t.discountAmount, 0);
	const totalRevenue = transactions.reduce((s, t) => s + t.amount, 0);
	return {
		totalCustomers: customers.length,
		totalWorkers: workers.length,
		activeWorkers: workers.filter((w) => w.status === "active").length,
		totalGroups: groups.filter((g) => g.active).length,
		totalTransactions: transactions.length,
		totalDiscount,
		totalRevenue,
		todayTransactions: transactions.filter((t) => dayKey(t.createdAt) === tk).length,
		todayDiscount: transactions.filter((t) => dayKey(t.createdAt) === tk).reduce((s, t) => s + t.discountAmount, 0),
		newRegistrations7d: customers.filter((c) => TODAY.getTime() - new Date(c.registeredAt).getTime() <= 6048e5).length,
		activeCustomers: customers.filter((c) => c.status === "active").length,
		usedPumpCustomers: customers.filter((c) => c.transactions > 0).length,
		unassignedCustomers: customers.filter((c) => c.groupId === DEFAULT_GROUP_ID).length,
		avgDiscountPercent: totalRevenue ? totalDiscount / totalRevenue * 100 : 0
	};
}
function buildSeries(customers, transactions, days) {
	const buckets = /* @__PURE__ */ new Map();
	for (let i = days - 1; i >= 0; i--) {
		const d = /* @__PURE__ */ new Date(TODAY.getTime() - i * 864e5);
		const key = d.toISOString().slice(0, 10);
		buckets.set(key, {
			date: key,
			label: d.toLocaleDateString("en-IN", {
				day: "2-digit",
				month: "short"
			}),
			transactions: 0,
			discount: 0,
			registrations: 0,
			revenue: 0
		});
	}
	transactions.forEach((t) => {
		const b = buckets.get(dayKey(t.createdAt));
		if (!b) return;
		b.transactions += 1;
		b.discount += t.discountAmount;
		b.revenue += t.amount;
	});
	customers.forEach((c) => {
		const b = buckets.get(dayKey(c.registeredAt));
		if (b) b.registrations += 1;
	});
	return [...buckets.values()];
}
function groupDistribution(customers, groups, transactions) {
	return groups.map((g) => ({
		id: g.id,
		name: g.name,
		discountPercent: g.discountPercent,
		active: g.active,
		customers: customers.filter((c) => c.groupId === g.id).length,
		discountGenerated: transactions.filter((t) => t.groupId === g.id).reduce((s, t) => s + t.discountAmount, 0),
		transactions: transactions.filter((t) => t.groupId === g.id).length
	}));
}
function workerActivity(workers) {
	return [...workers].sort((a, b) => b.scans - a.scans).map((w) => ({
		name: w.name.split(" ")[0],
		scans: w.scans,
		transactions: w.transactions
	}));
}
function rangeBounds(range, from, to) {
	const end = new Date(TODAY);
	end.setUTCHours(23, 59, 59, 999);
	const start = new Date(TODAY);
	start.setUTCHours(0, 0, 0, 0);
	if (range === "week") start.setUTCDate(start.getUTCDate() - 6);
	if (range === "month") start.setUTCDate(start.getUTCDate() - 29);
	if (range === "quarter") start.setUTCDate(start.getUTCDate() - 89);
	if (range === "custom") return {
		start: from ? /* @__PURE__ */ new Date(`${from}T00:00:00.000Z`) : start,
		end: to ? /* @__PURE__ */ new Date(`${to}T23:59:59.999Z`) : end
	};
	return {
		start,
		end
	};
}
function inRange(value, bounds) {
	const t = new Date(value).getTime();
	return t >= bounds.start.getTime() && t <= bounds.end.getTime();
}
function exportCsv(filename, rows) {
	if (!rows.length) return;
	const headers = Object.keys(rows[0]);
	const body = rows.map((r) => headers.map((h) => {
		const v = String(r[h] ?? "");
		return /[",\n]/.test(v) ? `"${v.replace(/"/g, "\"\"")}"` : v;
	}).join(","));
	const csv = [headers.join(","), ...body].join("\n");
	const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.click();
	URL.revokeObjectURL(url);
}
var AdminContext = (0, import_react.createContext)(null);
var AUTH_KEY = "fuelpoint-admin-authed";
function AdminProvider({ children }) {
	const [authed, setAuthed] = (0, import_react.useState)(false);
	const [profile, setProfile] = (0, import_react.useState)(() => adminService.getProfile());
	const [customers, setCustomers] = (0, import_react.useState)(() => adminService.getCustomers());
	const [groups, setGroups] = (0, import_react.useState)(() => adminService.getGroups());
	const [notifications, setNotifications] = (0, import_react.useState)(() => adminService.getNotifications());
	const workers = (0, import_react.useMemo)(() => adminService.getWorkers(), []);
	const transactions = (0, import_react.useMemo)(() => adminService.getTransactions(), []);
	(0, import_react.useEffect)(() => {
		if (sessionStorage.getItem(AUTH_KEY) === "1") setAuthed(true);
	}, []);
	const login = (0, import_react.useCallback)((email) => {
		setAuthed(true);
		setProfile((p) => ({
			...p,
			email: email || p.email
		}));
		if (typeof window !== "undefined") sessionStorage.setItem(AUTH_KEY, "1");
	}, []);
	const logout = (0, import_react.useCallback)(() => {
		setAuthed(false);
		if (typeof window !== "undefined") sessionStorage.removeItem(AUTH_KEY);
	}, []);
	const assignCustomerGroup = (0, import_react.useCallback)((customerId, groupId) => {
		setCustomers((prev) => prev.map((c) => {
			if (c.id !== customerId) return c;
			const g = groups.find((x) => x.id === groupId);
			return {
				...c,
				groupId,
				status: groupId === "grp-default" ? c.status : c.transactions > 0 ? "active" : c.status,
				discountReceived: Math.round(c.totalSpend * (g?.discountPercent ?? 0) / 100)
			};
		}));
		setNotifications((prev) => prev.map((n) => n.customerId === customerId ? {
			...n,
			read: true
		} : n));
	}, [groups]);
	const saveGroup = (0, import_react.useCallback)((group) => {
		setGroups((prev) => {
			if (prev.some((g) => g.id === group.id)) return prev.map((g) => g.id === group.id ? {
				...g,
				...group
			} : g);
			return [...prev, {
				...group,
				createdAt: group.createdAt ?? (/* @__PURE__ */ new Date()).toISOString()
			}];
		});
	}, []);
	const deleteGroup = (0, import_react.useCallback)((groupId) => {
		setGroups((prev) => prev.filter((g) => g.id !== groupId));
		setCustomers((prev) => prev.map((c) => c.groupId === groupId ? {
			...c,
			groupId: "grp-default",
			discountReceived: 0
		} : c));
	}, []);
	const toggleGroupActive = (0, import_react.useCallback)((groupId) => {
		setGroups((prev) => prev.map((g) => g.id === groupId ? {
			...g,
			active: !g.active
		} : g));
	}, []);
	const value = {
		authed,
		login,
		logout,
		profile,
		updateProfile: (patch) => setProfile((p) => ({
			...p,
			...patch
		})),
		customers,
		workers,
		groups,
		transactions,
		notifications,
		unreadCount: notifications.filter((n) => !n.read).length,
		assignCustomerGroup,
		saveGroup,
		deleteGroup,
		toggleGroupActive,
		markRead: (id) => setNotifications((prev) => prev.map((n) => n.id === id ? {
			...n,
			read: true
		} : n)),
		markAllRead: () => setNotifications((prev) => prev.map((n) => ({
			...n,
			read: true
		})))
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminContext.Provider, {
		value,
		children
	});
}
function useAdmin() {
	const ctx = (0, import_react.useContext)(AdminContext);
	if (!ctx) throw new Error("useAdmin must be used inside AdminProvider");
	return ctx;
}
//#endregion
export { exportCsv as a, formatDateTime as c, inRange as d, rangeBounds as f, workerActivity as h, buildSeries as i, formatNumber as l, useAdmin as m, DEFAULT_GROUP_ID as n, formatCurrency as o, relativeDays as p, buildOverview as r, formatDate as s, AdminProvider as t, groupDistribution as u };
