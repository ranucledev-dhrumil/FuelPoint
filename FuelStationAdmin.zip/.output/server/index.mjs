globalThis.__nitro_main__ = import.meta.url;
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-09-23T14:36:00.231Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"ae-hLVBrSrDdpIw3Xl0dJPRkupPepQ\"",
		"mtime": "2026-09-23T14:36:00.232Z",
		"size": 174,
		"path": "../public/robots.txt"
	},
	"/assets/activity-Ccsa6xeH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"de-JDvQC2x8TUkgBr6YOpWYdehQzV0\"",
		"mtime": "2026-09-24T07:23:21.174Z",
		"size": 222,
		"path": "../public/assets/activity-Ccsa6xeH.js"
	},
	"/assets/badge-percent-DmD9sZYX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"17a-5ZM4gMPs9OdseMk/pj2EQxSZsFs\"",
		"mtime": "2026-09-24T07:23:21.215Z",
		"size": 378,
		"path": "../public/assets/badge-percent-DmD9sZYX.js"
	},
	"/assets/admin-store-C0BxZwjZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5701-elpQNa7xb/vsuqzEHMpMzeZ3Tog\"",
		"mtime": "2026-09-24T07:23:21.177Z",
		"size": 22273,
		"path": "../public/assets/admin-store-C0BxZwjZ.js"
	},
	"/assets/bell-pheB03YT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"116-NK5SNxd86XVZ6lUuETFx/kQ8+Fk\"",
		"mtime": "2026-09-24T07:23:21.222Z",
		"size": 278,
		"path": "../public/assets/bell-pheB03YT.js"
	},
	"/assets/button-BuKE1S1_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"75e-8Cf5jV9BmkR9C8EbMz8W20E0pdY\"",
		"mtime": "2026-09-24T07:23:21.222Z",
		"size": 1886,
		"path": "../public/assets/button-BuKE1S1_.js"
	},
	"/assets/chevron-right-C0jliPiD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"76-pucMa+S4RDH6jbTvWQFQQepmj+0\"",
		"mtime": "2026-09-24T07:23:22.610Z",
		"size": 118,
		"path": "../public/assets/chevron-right-C0jliPiD.js"
	},
	"/assets/dist-BaCfQnzJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"29e-7rrcCt4phMU5sOOsMuUdg9y89/Y\"",
		"mtime": "2026-09-24T07:23:22.634Z",
		"size": 670,
		"path": "../public/assets/dist-BaCfQnzJ.js"
	},
	"/assets/dialog-C6CPZtr2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18c4-/RQJIh4VwuDLvQyM1b1p1Ca2Rt8\"",
		"mtime": "2026-09-24T07:23:22.624Z",
		"size": 6340,
		"path": "../public/assets/dialog-C6CPZtr2.js"
	},
	"/assets/DataTable-Bj5HMTq6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"edc-3SYENbA1lUIysteuiRf2SVoaCW4\"",
		"mtime": "2026-09-24T07:23:20.955Z",
		"size": 3804,
		"path": "../public/assets/DataTable-Bj5HMTq6.js"
	},
	"/assets/dist-CFRJSLDd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5abc-6SBJpELU88y5LB2/H3ZHBUk8LMU\"",
		"mtime": "2026-09-24T07:23:22.636Z",
		"size": 23228,
		"path": "../public/assets/dist-CFRJSLDd.js"
	},
	"/assets/charts-DYTuPszZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"66966-/+VsWMx5FDP8E6syRq3Hoe4wN9U\"",
		"mtime": "2026-09-24T07:23:21.222Z",
		"size": 420198,
		"path": "../public/assets/charts-DYTuPszZ.js"
	},
	"/assets/dist-CYU0HbC2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7be8-wpRQHx9q+SjZNf6dRgQIHoMv2vQ\"",
		"mtime": "2026-09-24T07:23:22.672Z",
		"size": 31720,
		"path": "../public/assets/dist-CYU0HbC2.js"
	},
	"/assets/dist-DsmpH0au.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6448-jKvyFW1TKXrRuwxYuRzLnfbRBIs\"",
		"mtime": "2026-09-24T07:23:22.710Z",
		"size": 25672,
		"path": "../public/assets/dist-DsmpH0au.js"
	},
	"/assets/dist-gP8ulO1f.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d04-hN+Tf0JvBziUTMYl6WFU6MKBnlU\"",
		"mtime": "2026-09-24T07:23:22.748Z",
		"size": 7428,
		"path": "../public/assets/dist-gP8ulO1f.js"
	},
	"/assets/dist-CQAkbLm3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c9d-P1NRxucn6yrfxq8V553NUI0hoak\"",
		"mtime": "2026-09-24T07:23:22.658Z",
		"size": 7325,
		"path": "../public/assets/dist-CQAkbLm3.js"
	},
	"/assets/dist-RgY4U8_2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1079-VYVM2rZScZOrx7UGBBnzMD0G6dM\"",
		"mtime": "2026-09-24T07:23:22.743Z",
		"size": 4217,
		"path": "../public/assets/dist-RgY4U8_2.js"
	},
	"/assets/fuel-CJcTiZpT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"134-9w5nvzKF6wwtJmbIOYzTvkRFqhw\"",
		"mtime": "2026-09-24T07:23:22.757Z",
		"size": 308,
		"path": "../public/assets/fuel-CJcTiZpT.js"
	},
	"/assets/label-DZjqHu78.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4be-cHc6xT91+ExxOCHCGAsvTNuQTLw\"",
		"mtime": "2026-09-24T07:23:22.757Z",
		"size": 1214,
		"path": "../public/assets/label-DZjqHu78.js"
	},
	"/assets/primitives-DWcMo8UZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e0b-SB20svNACqaZqRWvQGLbuQfo+ok\"",
		"mtime": "2026-09-24T07:23:22.766Z",
		"size": 3595,
		"path": "../public/assets/primitives-DWcMo8UZ.js"
	},
	"/assets/routes-0MRpZ-uk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"28e5-LXfD/V921fTkpDALaIroBg2CtSA\"",
		"mtime": "2026-09-24T07:23:22.771Z",
		"size": 10469,
		"path": "../public/assets/routes-0MRpZ-uk.js"
	},
	"/assets/search-BQOvqEot.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a2-93xCEaSOLlbpOFza110QxFkd6OA\"",
		"mtime": "2026-09-24T07:23:22.792Z",
		"size": 162,
		"path": "../public/assets/search-BQOvqEot.js"
	},
	"/assets/select-D_cV-h4w.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"577b-8altMzFB8ns25UJd3NURiiLCfe4\"",
		"mtime": "2026-09-24T07:23:22.797Z",
		"size": 22395,
		"path": "../public/assets/select-D_cV-h4w.js"
	},
	"/assets/index-DPN8V-HE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"62e0b-XQ31jSDM2Qw/Vq71DchvXXadLRg\"",
		"mtime": "2026-09-24T07:23:20.093Z",
		"size": 405003,
		"path": "../public/assets/index-DPN8V-HE.js"
	},
	"/assets/shield-check-D2yybNZK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"134-V21LrXmTvJUgZvsFMK+OAUn6bV8\"",
		"mtime": "2026-09-24T07:23:22.874Z",
		"size": 308,
		"path": "../public/assets/shield-check-D2yybNZK.js"
	},
	"/assets/tags-BXnDY_DT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"194-Dz2B6eehv6uSMbs18x+Li5JQ9Mw\"",
		"mtime": "2026-09-24T07:23:22.879Z",
		"size": 404,
		"path": "../public/assets/tags-BXnDY_DT.js"
	},
	"/assets/user-check-CfcS3PyY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e7-miYClleSYOV96TBOQyN9RPk+6XA\"",
		"mtime": "2026-09-24T07:23:22.880Z",
		"size": 231,
		"path": "../public/assets/user-check-CfcS3PyY.js"
	},
	"/assets/styles-Bo44Ngd_.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"14eaf-XF1YV5T3BgA9VTbhYesp3bXapys\"",
		"mtime": "2026-09-24T07:23:22.907Z",
		"size": 85679,
		"path": "../public/assets/styles-Bo44Ngd_.css"
	},
	"/assets/users-DnzLXy2m.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"126-yTwP7FyedJKKnGgBwszVefL8iwY\"",
		"mtime": "2026-09-24T07:23:22.897Z",
		"size": 294,
		"path": "../public/assets/users-DnzLXy2m.js"
	},
	"/assets/user-plus-32-BOoWb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12a-Ko6bWUdqqVvKHPRljZvu/Q1pTD4\"",
		"mtime": "2026-09-24T07:23:22.884Z",
		"size": 298,
		"path": "../public/assets/user-plus-32-BOoWb.js"
	},
	"/assets/wrench-ClNhh5tx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"123-TragMUuUH2LO19Ffto0cbi5J6yY\"",
		"mtime": "2026-09-24T07:23:22.902Z",
		"size": 291,
		"path": "../public/assets/wrench-ClNhh5tx.js"
	},
	"/assets/_admin-RumhXdUr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6bc5-cEajqXPopjQUEapGOlzn9SUR4h0\"",
		"mtime": "2026-09-24T07:23:20.974Z",
		"size": 27589,
		"path": "../public/assets/_admin-RumhXdUr.js"
	},
	"/assets/_admin.dashboard-DtM_hHDJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16ea-TwS+z8UrqhH5gh55ihK+LpVe6Oc\"",
		"mtime": "2026-09-24T07:23:21.054Z",
		"size": 5866,
		"path": "../public/assets/_admin.dashboard-DtM_hHDJ.js"
	},
	"/assets/_admin.customers-DB8hqKEb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b55-KKXqMfeidNweCCznyVHOytkcy+Y\"",
		"mtime": "2026-09-24T07:23:21.024Z",
		"size": 6997,
		"path": "../public/assets/_admin.customers-DB8hqKEb.js"
	},
	"/assets/_admin.groups-BFUoqmnv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2199-vSJTLguFZQa/R4sFjNxv4rOBG9Q\"",
		"mtime": "2026-09-24T07:23:21.067Z",
		"size": 8601,
		"path": "../public/assets/_admin.groups-BFUoqmnv.js"
	},
	"/assets/_admin.notifications-CqxXOioa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e89-wVt2RXhvv+MEomg0hg99NBlgr6I\"",
		"mtime": "2026-09-24T07:23:21.080Z",
		"size": 3721,
		"path": "../public/assets/_admin.notifications-CqxXOioa.js"
	},
	"/assets/_admin.profile-B_p8P5On.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1806-r7qf+g7VOvfiAqyXJDG4XEIQliI\"",
		"mtime": "2026-09-24T07:23:21.094Z",
		"size": 6150,
		"path": "../public/assets/_admin.profile-B_p8P5On.js"
	},
	"/assets/_admin.workers-mr1A-fnC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1cb0-f433G/1M7W28PppIEaMnmQAgO2E\"",
		"mtime": "2026-09-24T07:23:21.172Z",
		"size": 7344,
		"path": "../public/assets/_admin.workers-mr1A-fnC.js"
	},
	"/assets/_admin.reports-ClaPECj7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3c21-BLrPHBtouWnswa14kPAN/cXe7X8\"",
		"mtime": "2026-09-24T07:23:21.112Z",
		"size": 15393,
		"path": "../public/assets/_admin.reports-ClaPECj7.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_v6IH_7 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_v6IH_7
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
