//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DCXdXZwQ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/Admin/Desktop/petrolpump/pumpmaster-pro/src/routes/__root.tsx",
		children: ["/", "/_admin"],
		preloads: ["/assets/index-DPN8V-HE.js", "/assets/admin-store-C0BxZwjZ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DPN8V-HE.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/Admin/Desktop/petrolpump/pumpmaster-pro/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-0MRpZ-uk.js",
			"/assets/dist-CYU0HbC2.js",
			"/assets/dist-CFRJSLDd.js",
			"/assets/fuel-CJcTiZpT.js",
			"/assets/shield-check-D2yybNZK.js",
			"/assets/button-BuKE1S1_.js",
			"/assets/dist-gP8ulO1f.js",
			"/assets/dist-BaCfQnzJ.js",
			"/assets/dialog-C6CPZtr2.js",
			"/assets/label-DZjqHu78.js"
		]
	},
	"/_admin": {
		filePath: "C:/Users/Admin/Desktop/petrolpump/pumpmaster-pro/src/routes/_admin.tsx",
		children: [
			"/_admin/customers",
			"/_admin/dashboard",
			"/_admin/groups",
			"/_admin/notifications",
			"/_admin/profile",
			"/_admin/reports",
			"/_admin/workers"
		],
		preloads: [
			"/assets/_admin-RumhXdUr.js",
			"/assets/dist-CYU0HbC2.js",
			"/assets/bell-pheB03YT.js",
			"/assets/dist-CFRJSLDd.js",
			"/assets/dist-DsmpH0au.js",
			"/assets/chevron-right-C0jliPiD.js",
			"/assets/fuel-CJcTiZpT.js",
			"/assets/search-BQOvqEot.js",
			"/assets/tags-BXnDY_DT.js",
			"/assets/users-DnzLXy2m.js",
			"/assets/wrench-ClNhh5tx.js",
			"/assets/dist-gP8ulO1f.js",
			"/assets/dist-BaCfQnzJ.js",
			"/assets/dist-CQAkbLm3.js",
			"/assets/dist-RgY4U8_2.js"
		]
	},
	"/_admin/customers": {
		filePath: "C:/Users/Admin/Desktop/petrolpump/pumpmaster-pro/src/routes/_admin.customers.tsx",
		children: void 0,
		preloads: [
			"/assets/_admin.customers-DB8hqKEb.js",
			"/assets/primitives-DWcMo8UZ.js",
			"/assets/DataTable-Bj5HMTq6.js",
			"/assets/select-D_cV-h4w.js",
			"/assets/user-check-CfcS3PyY.js",
			"/assets/user-plus-32-BOoWb.js",
			"/assets/button-BuKE1S1_.js",
			"/assets/dialog-C6CPZtr2.js"
		]
	},
	"/_admin/dashboard": {
		filePath: "C:/Users/Admin/Desktop/petrolpump/pumpmaster-pro/src/routes/_admin.dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/_admin.dashboard-DtM_hHDJ.js",
			"/assets/activity-Ccsa6xeH.js",
			"/assets/primitives-DWcMo8UZ.js",
			"/assets/badge-percent-DmD9sZYX.js",
			"/assets/user-plus-32-BOoWb.js",
			"/assets/button-BuKE1S1_.js",
			"/assets/charts-DYTuPszZ.js"
		]
	},
	"/_admin/groups": {
		filePath: "C:/Users/Admin/Desktop/petrolpump/pumpmaster-pro/src/routes/_admin.groups.tsx",
		children: void 0,
		preloads: [
			"/assets/_admin.groups-BFUoqmnv.js",
			"/assets/primitives-DWcMo8UZ.js",
			"/assets/badge-percent-DmD9sZYX.js",
			"/assets/select-D_cV-h4w.js",
			"/assets/button-BuKE1S1_.js",
			"/assets/dialog-C6CPZtr2.js",
			"/assets/charts-DYTuPszZ.js",
			"/assets/label-DZjqHu78.js"
		]
	},
	"/_admin/notifications": {
		filePath: "C:/Users/Admin/Desktop/petrolpump/pumpmaster-pro/src/routes/_admin.notifications.tsx",
		children: void 0,
		preloads: [
			"/assets/_admin.notifications-CqxXOioa.js",
			"/assets/primitives-DWcMo8UZ.js",
			"/assets/user-plus-32-BOoWb.js",
			"/assets/button-BuKE1S1_.js"
		]
	},
	"/_admin/profile": {
		filePath: "C:/Users/Admin/Desktop/petrolpump/pumpmaster-pro/src/routes/_admin.profile.tsx",
		children: void 0,
		preloads: [
			"/assets/_admin.profile-B_p8P5On.js",
			"/assets/primitives-DWcMo8UZ.js",
			"/assets/shield-check-D2yybNZK.js",
			"/assets/button-BuKE1S1_.js",
			"/assets/label-DZjqHu78.js"
		]
	},
	"/_admin/reports": {
		filePath: "C:/Users/Admin/Desktop/petrolpump/pumpmaster-pro/src/routes/_admin.reports.tsx",
		children: void 0,
		preloads: [
			"/assets/_admin.reports-ClaPECj7.js",
			"/assets/primitives-DWcMo8UZ.js",
			"/assets/DataTable-Bj5HMTq6.js",
			"/assets/button-BuKE1S1_.js",
			"/assets/charts-DYTuPszZ.js",
			"/assets/label-DZjqHu78.js"
		]
	},
	"/_admin/workers": {
		filePath: "C:/Users/Admin/Desktop/petrolpump/pumpmaster-pro/src/routes/_admin.workers.tsx",
		children: void 0,
		preloads: [
			"/assets/_admin.workers-mr1A-fnC.js",
			"/assets/activity-Ccsa6xeH.js",
			"/assets/primitives-DWcMo8UZ.js",
			"/assets/badge-percent-DmD9sZYX.js",
			"/assets/DataTable-Bj5HMTq6.js",
			"/assets/select-D_cV-h4w.js",
			"/assets/user-check-CfcS3PyY.js",
			"/assets/button-BuKE1S1_.js",
			"/assets/dialog-C6CPZtr2.js",
			"/assets/charts-DYTuPszZ.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
