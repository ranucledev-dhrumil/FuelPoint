import { i as __toESM } from "./_runtime.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { a as exportCsv, c as formatDateTime, d as inRange, f as rangeBounds, i as buildSeries, l as formatNumber, m as useAdmin, o as formatCurrency, s as formatDate, u as groupDistribution } from "./_ssr/admin-store-DLYihnwj.mjs";
import { t as cn } from "./_ssr/utils-C_uf36nf.mjs";
import { S as FileSpreadsheet, w as Download } from "./_libs/lucide-react.mjs";
import { n as TablePagination } from "./_ssr/DataTable-C6ZgHd1t.mjs";
import { a as StatusBadge, n as PageHeader, r as Panel } from "./_ssr/primitives-BY6eLzWO.mjs";
import { t as Button } from "./_ssr/button-Bq5vK6RO.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { i as TrendAreaChart, n as HorizontalBarChart, t as DonutChart } from "./_ssr/charts-CYjSJrBW.mjs";
import { n as Label, t as Input } from "./_ssr/label-B7oQAA24.mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "./_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_admin.reports-BKQEyupj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Tabs = Root2;
var TabsList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
	ref,
	className: cn("inline-flex h-9 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground", className),
	...props
}));
TabsList.displayName = List.displayName;
var TabsTrigger = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
	ref,
	className: cn("inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background cursor-pointer transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow", className),
	...props
}));
TabsTrigger.displayName = Trigger.displayName;
var TabsContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
	ref,
	className: cn("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
	...props
}));
TabsContent.displayName = Content.displayName;
var rangeOptions = [
	{
		key: "today",
		label: "Today"
	},
	{
		key: "week",
		label: "This week"
	},
	{
		key: "month",
		label: "This month"
	},
	{
		key: "quarter",
		label: "90 days"
	},
	{
		key: "custom",
		label: "Custom"
	}
];
var categories = [
	{
		key: "transactions",
		label: "Transactions"
	},
	{
		key: "discount",
		label: "Discount"
	},
	{
		key: "customers",
		label: "Customers"
	},
	{
		key: "workers",
		label: "Workers"
	},
	{
		key: "groups",
		label: "Groups"
	}
];
function ReportsPage() {
	const { customers, workers, groups, transactions } = useAdmin();
	const [range, setRange] = (0, import_react.useState)("month");
	const [from, setFrom] = (0, import_react.useState)("2026-09-01");
	const [to, setTo] = (0, import_react.useState)("2026-09-23");
	const [category, setCategory] = (0, import_react.useState)("transactions");
	const [page, setPage] = (0, import_react.useState)(1);
	const pageSize = 10;
	(0, import_react.useEffect)(() => {
		setPage(1);
	}, [
		range,
		from,
		to,
		category
	]);
	const bounds = (0, import_react.useMemo)(() => rangeBounds(range, from, to), [
		range,
		from,
		to
	]);
	const txns = (0, import_react.useMemo)(() => transactions.filter((t) => inRange(t.createdAt, bounds)), [transactions, bounds]);
	const regs = (0, import_react.useMemo)(() => customers.filter((c) => inRange(c.registeredAt, bounds)), [customers, bounds]);
	const days = Math.max(1, Math.round((bounds.end.getTime() - bounds.start.getTime()) / 864e5) + 1);
	const series = (0, import_react.useMemo)(() => buildSeries(customers, txns, Math.min(days, 90)), [
		customers,
		txns,
		days
	]);
	const dist = (0, import_react.useMemo)(() => groupDistribution(customers, groups, txns), [
		customers,
		groups,
		txns
	]);
	const totalTxnPages = Math.max(1, Math.ceil(txns.length / pageSize));
	const safeTxnPage = Math.min(page, totalTxnPages);
	const pagedTxns = (0, import_react.useMemo)(() => txns.slice((safeTxnPage - 1) * pageSize, safeTxnPage * pageSize), [
		txns,
		safeTxnPage,
		pageSize
	]);
	const totalRegPages = Math.max(1, Math.ceil(regs.length / pageSize));
	const safeRegPage = Math.min(page, totalRegPages);
	const pagedRegs = (0, import_react.useMemo)(() => regs.slice((safeRegPage - 1) * pageSize, safeRegPage * pageSize), [
		regs,
		safeRegPage,
		pageSize
	]);
	const discountTotal = txns.reduce((s, t) => s + t.discountAmount, 0);
	const revenueTotal = txns.reduce((s, t) => s + t.amount, 0);
	const litresTotal = Math.round(txns.reduce((s, t) => s + t.litres, 0));
	const summary = {
		transactions: [
			["Transactions", formatNumber(txns.length)],
			["Revenue", formatCurrency(revenueTotal)],
			["Litres dispensed", formatNumber(litresTotal)],
			["Avg ticket", formatCurrency(txns.length ? revenueTotal / txns.length : 0)]
		],
		discount: [
			["Discount given", formatCurrency(discountTotal)],
			["Effective rate", `${revenueTotal ? (discountTotal / revenueTotal * 100).toFixed(2) : "0"}%`],
			["Discounted scans", formatNumber(txns.filter((t) => t.discountAmount > 0).length)],
			["Avg discount/scan", formatCurrency(txns.length ? discountTotal / txns.length : 0)]
		],
		customers: [
			["New registrations", formatNumber(regs.length)],
			["Total customers", formatNumber(customers.length)],
			["Active", formatNumber(customers.filter((c) => c.status === "active").length)],
			["Unassigned", formatNumber(customers.filter((c) => c.groupId === "grp-default").length)]
		],
		workers: [
			["Workers", formatNumber(workers.length)],
			["Active", formatNumber(workers.filter((w) => w.status === "active").length)],
			["Scans in range", formatNumber(txns.length)],
			["Discount processed", formatCurrency(discountTotal)]
		],
		groups: [
			["Groups", formatNumber(groups.length)],
			["Active groups", formatNumber(groups.filter((g) => g.active).length)],
			["Group discount", formatCurrency(discountTotal)],
			["Grouped customers", formatNumber(customers.filter((c) => c.groupId !== "grp-default").length)]
		]
	}[category];
	const exportRows = () => {
		if (category === "customers") return regs.map((c) => ({
			ID: c.id,
			Name: c.name,
			Phone: c.phone,
			Group: groups.find((g) => g.id === c.groupId)?.name ?? "",
			Registered: formatDate(c.registeredAt),
			Transactions: c.transactions,
			Discount: c.discountReceived
		}));
		if (category === "workers") return workers.map((w) => ({
			ID: w.id,
			Name: w.name,
			Status: w.status,
			Scans: w.scans,
			Transactions: w.transactions,
			DiscountProcessed: w.discountProcessed,
			LastActivity: formatDate(w.lastActivity)
		}));
		if (category === "groups") return dist.map((g) => ({
			Group: g.name,
			DiscountPercent: g.discountPercent,
			Customers: g.customers,
			Transactions: g.transactions,
			DiscountGenerated: g.discountGenerated
		}));
		return txns.map((t) => ({
			ID: t.id,
			Date: formatDateTime(t.createdAt),
			Customer: t.customerName,
			Worker: t.workerName,
			Fuel: t.fuel,
			Litres: t.litres,
			Amount: t.amount,
			DiscountPercent: t.discountPercent,
			Discount: t.discountAmount
		}));
	};
	const handleExport = (kind) => {
		const rows = exportRows();
		if (!rows.length) {
			toast.error("Nothing to export for this range.");
			return;
		}
		exportCsv(`${category}-report.${kind === "csv" ? "csv" : "xls.csv"}`, rows);
		toast.success(`${kind === "csv" ? "CSV" : "Excel-ready"} report exported`, { description: `${rows.length} rows · ${formatDate(bounds.start.toISOString())} → ${formatDate(bounds.end.toISOString())}` });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Reports",
			subtitle: "Date-ranged reporting across customers, workers, scans, discounts and groups.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				onClick: () => handleExport("csv"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), " Export CSV"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => handleExport("excel"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, { className: "size-4" }), " Export Excel"]
			})] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "surface-card flex flex-wrap items-end gap-3 p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap items-center gap-1 rounded-lg border border-border p-1",
					children: rangeOptions.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setRange(r.key),
						className: range === r.key ? "rounded-md bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground" : "rounded-md px-3 py-1.5 text-xs font-medium text-muted-foreground hover:bg-muted",
						children: r.label
					}, r.key))
				}),
				range === "custom" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "from",
							className: "text-xs",
							children: "From"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "from",
							type: "date",
							value: from,
							onChange: (e) => setFrom(e.target.value),
							className: "w-40"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "to",
							className: "text-xs",
							children: "To"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "to",
							type: "date",
							value: to,
							onChange: (e) => setTo(e.target.value),
							className: "w-40"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "ml-auto text-xs text-muted-foreground",
					children: [
						formatDate(bounds.start.toISOString()),
						" → ",
						formatDate(bounds.end.toISOString()),
						" ·",
						" ",
						formatNumber(txns.length),
						" scans in range"
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
			value: category,
			onValueChange: (v) => setCategory(v),
			className: "mt-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsList, { children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
				value: c.key,
				children: c.label
			}, c.key)) })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid grid-cols-2 gap-4 lg:grid-cols-4",
			children: summary.map(([l, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "surface-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: l
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xl font-bold text-foreground",
					children: v
				})]
			}, l))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid gap-4 lg:grid-cols-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: category === "customers" ? "Registrations trend" : "Activity trend",
				description: "Daily movement inside the selected range",
				className: "lg:col-span-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendAreaChart, {
					data: series,
					dataKey: category === "customers" ? "registrations" : category === "discount" ? "discount" : "transactions",
					color: category === "discount" ? "var(--teal)" : "var(--primary)",
					valueFormatter: category === "discount" ? formatCurrency : void 0
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: category === "workers" ? "Scans by worker" : "Group distribution",
				description: category === "workers" ? "Volume per worker" : "Customers per group",
				children: category === "workers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HorizontalBarChart, {
					data: workers.map((w) => ({
						name: w.name.split(" ")[0],
						scans: w.scans
					})),
					dataKey: "scans",
					height: 280
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DonutChart, { data: dist.filter((g) => g.customers > 0).map((g) => ({
					name: g.name,
					value: g.customers
				})) })
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			title: `${categories.find((c) => c.key === category).label} report`,
			description: "Tabular detail for the selected range",
			className: "mt-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-x-auto",
				children: [
					category === "workers" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[720px] text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "border-b border-border bg-muted/50 text-xs uppercase text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
								"Worker",
								"Status",
								"Scans",
								"Transactions",
								"Discount processed",
								"Last activity"
							].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 text-left font-semibold",
								children: h
							}, h)) })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: workers.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border/70 last:border-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-medium",
									children: w.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: w.status })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: formatNumber(w.scans)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: formatNumber(w.transactions)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-teal",
									children: formatCurrency(w.discountProcessed)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted-foreground",
									children: formatDate(w.lastActivity)
								})
							]
						}, w.id)) })]
					}),
					category === "groups" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[720px] text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "border-b border-border bg-muted/50 text-xs uppercase text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
								"Group",
								"Discount %",
								"Customers",
								"Transactions",
								"Discount generated"
							].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 text-left font-semibold",
								children: h
							}, h)) })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: dist.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border/70 last:border-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-medium",
									children: g.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-4 py-3",
									children: [g.discountPercent, "%"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: formatNumber(g.customers)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: formatNumber(g.transactions)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-teal",
									children: formatCurrency(g.discountGenerated)
								})
							]
						}, g.id)) })]
					}),
					category === "customers" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[720px] text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "border-b border-border bg-muted/50 text-xs uppercase text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
								"Customer",
								"Registered",
								"Group",
								"Transactions",
								"Discount received",
								"Status"
							].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 text-left font-semibold",
								children: h
							}, h)) })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [pagedRegs.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border/70 last:border-0 hover:bg-muted/30 transition-colors",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-medium text-foreground",
									children: c.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted-foreground",
									children: formatDate(c.registeredAt)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: groups.find((g) => g.id === c.groupId)?.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: formatNumber(c.transactions)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-medium text-teal",
									children: formatCurrency(c.discountReceived)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: c.status })
								})
							]
						}, c.id)), pagedRegs.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 6,
							className: "px-4 py-12 text-center text-sm text-muted-foreground",
							children: "No registrations in this range."
						}) })] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TablePagination, {
						currentPage: safeRegPage,
						totalPages: totalRegPages,
						pageSize,
						totalItems: regs.length,
						currentCount: pagedRegs.length,
						onPageChange: setPage
					})] }),
					(category === "transactions" || category === "discount") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[820px] text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "border-b border-border bg-muted/50 text-xs uppercase text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
								"Txn",
								"Date",
								"Customer",
								"Worker",
								"Fuel",
								"Amount",
								"Discount"
							].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 text-left font-semibold",
								children: h
							}, h)) })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [pagedTxns.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border/70 last:border-0 hover:bg-muted/30 transition-colors",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-mono text-xs text-muted-foreground",
									children: t.id
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted-foreground",
									children: formatDateTime(t.createdAt)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-medium text-foreground",
									children: t.customerName
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-foreground",
									children: t.workerName
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-4 py-3 text-muted-foreground",
									children: [
										t.fuel,
										" · ",
										t.litres,
										" L"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-medium text-foreground",
									children: formatCurrency(t.amount)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-4 py-3 font-medium text-teal",
									children: [
										"−",
										formatCurrency(t.discountAmount),
										" (",
										t.discountPercent,
										"%)"
									]
								})
							]
						}, t.id)), pagedTxns.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 7,
							className: "px-4 py-12 text-center text-sm text-muted-foreground",
							children: "No transactions in this range."
						}) })] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TablePagination, {
						currentPage: safeTxnPage,
						totalPages: totalTxnPages,
						pageSize,
						totalItems: txns.length,
						currentCount: pagedTxns.length,
						onPageChange: setPage
					})] })
				]
			})
		})
	] });
}
//#endregion
export { ReportsPage as component };
