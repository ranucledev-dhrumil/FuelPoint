import { i as __toESM } from "./_runtime.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { c as formatDateTime, l as formatNumber, m as useAdmin, o as formatCurrency, p as relativeDays, s as formatDate } from "./_ssr/admin-store-DLYihnwj.mjs";
import { H as Activity, R as BadgePercent, a as UserCheck, n as Wrench, u as Search } from "./_libs/lucide-react.mjs";
import { t as DataTable } from "./_ssr/DataTable-C6ZgHd1t.mjs";
import { a as StatusBadge, i as StatCard, n as PageHeader, r as Panel } from "./_ssr/primitives-BY6eLzWO.mjs";
import { t as Button } from "./_ssr/button-Bq5vK6RO.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./_ssr/dialog-CwLzEEob.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./_ssr/select-Dg1urBTx.mjs";
import { n as HorizontalBarChart } from "./_ssr/charts-CYjSJrBW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_admin.workers-203z4DCK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function WorkersPage() {
	const { workers, transactions } = useAdmin();
	const [query, setQuery] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("all");
	const [shift, setShift] = (0, import_react.useState)("all");
	const [selected, setSelected] = (0, import_react.useState)(null);
	const filtered = (0, import_react.useMemo)(() => workers.filter((w) => (status === "all" || w.status === status) && (shift === "all" || w.shift === shift) && (w.name.toLowerCase().includes(query.toLowerCase()) || w.id.toLowerCase().includes(query.toLowerCase()) || w.email.toLowerCase().includes(query.toLowerCase()))), [
		workers,
		query,
		status,
		shift
	]);
	const totals = (0, import_react.useMemo)(() => ({
		scans: workers.reduce((s, w) => s + w.scans, 0),
		discount: workers.reduce((s, w) => s + w.discountProcessed, 0),
		active: workers.filter((w) => w.status === "active").length
	}), [workers]);
	const scansData = (0, import_react.useMemo)(() => [...workers].sort((a, b) => b.scans - a.scans).map((w) => ({
		name: w.name,
		scans: w.scans
	})), [workers]);
	const discountData = (0, import_react.useMemo)(() => [...workers].sort((a, b) => b.discountProcessed - a.discountProcessed).map((w) => ({
		name: w.name,
		discount: w.discountProcessed
	})), [workers]);
	const columns = [
		{
			key: "name",
			header: "Worker",
			sortValue: (w) => w.name,
			render: (w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "gradient-brand flex size-9 items-center justify-center rounded-full text-xs font-semibold text-primary-foreground",
					children: w.name.split(" ").map((n) => n[0]).join("")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium text-foreground",
					children: w.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [
						w.id,
						" · ",
						w.shift,
						" shift"
					]
				})] })]
			})
		},
		{
			key: "status",
			header: "Status",
			sortValue: (w) => w.status,
			render: (w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: w.status })
		},
		{
			key: "scans",
			header: "Scans",
			align: "right",
			sortValue: (w) => w.scans,
			render: (w) => formatNumber(w.scans)
		},
		{
			key: "customers",
			header: "Customers",
			align: "right",
			sortValue: (w) => w.customersScanned,
			render: (w) => formatNumber(w.customersScanned)
		},
		{
			key: "transactions",
			header: "Transactions",
			align: "right",
			sortValue: (w) => w.transactions,
			render: (w) => formatNumber(w.transactions)
		},
		{
			key: "discount",
			header: "Discount processed",
			align: "right",
			sortValue: (w) => w.discountProcessed,
			render: (w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium text-teal",
				children: formatCurrency(w.discountProcessed)
			})
		},
		{
			key: "last",
			header: "Last activity",
			align: "right",
			sortValue: (w) => w.lastActivity,
			render: (w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-muted-foreground",
				children: relativeDays(w.lastActivity)
			})
		}
	];
	const workerTxns = selected ? transactions.filter((t) => t.workerId === selected.id).slice(0, 8) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Workers",
			subtitle: "Scanning activity and discount handling per worker."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Total workers",
					value: formatNumber(workers.length),
					icon: Wrench
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Active workers",
					value: formatNumber(totals.active),
					icon: UserCheck,
					tone: "teal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Total scans",
					value: formatNumber(totals.scans),
					icon: Activity,
					tone: "navy"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Discount processed",
					value: formatCurrency(totals.discount),
					icon: BadgePercent,
					tone: "teal"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			title: "Worker directory",
			description: "Search, filter and sort the team",
			className: "mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex flex-wrap items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-56 flex-1 items-center gap-2 rounded-lg border border-border px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: query,
							onChange: (e) => setQuery(e.target.value),
							placeholder: "Search by name, ID or email",
							className: "w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: status,
						onValueChange: setStatus,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "w-36",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "all",
								children: "All statuses"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "active",
								children: "Active"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "offline",
								children: "Offline"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "suspended",
								children: "Suspended"
							})
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: shift,
						onValueChange: setShift,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "w-36",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "all",
								children: "All shifts"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Morning",
								children: "Morning"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Evening",
								children: "Evening"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Night",
								children: "Night"
							})
						] })]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				rows: filtered,
				columns,
				pageSize: 8,
				onRowClick: setSelected
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold tracking-tight text-foreground",
					children: "Worker performance"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Comparative breakdown of scans handled and discount processed by team members"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Scans by worker",
					description: "Ranked by total scans handled",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HorizontalBarChart, {
						data: scansData,
						dataKey: "scans",
						height: 320,
						color: "var(--primary)",
						yAxisWidth: 110
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Discount processed by worker",
					description: "Ranked by total discount value processed",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HorizontalBarChart, {
						data: discountData,
						dataKey: "discount",
						height: 320,
						color: "var(--teal)",
						valueFormatter: formatCurrency,
						yAxisWidth: 110
					})
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: !!selected,
			onOpenChange: (o) => !o && setSelected(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
				className: "sm:max-w-xl",
				children: selected && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: selected.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
						selected.id,
						" · ",
						selected.shift,
						" shift · joined ",
						formatDate(selected.joinedAt)
					] })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-3 sm:grid-cols-4",
						children: [
							["Scans", formatNumber(selected.scans)],
							["Customers", formatNumber(selected.customersScanned)],
							["Transactions", formatNumber(selected.transactions)],
							["Discount", formatCurrency(selected.discountProcessed)]
						].map(([l, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-border bg-muted/40 p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: l
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm font-semibold text-foreground",
								children: v
							})]
						}, l))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-border",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "border-b border-border px-4 py-2.5 text-xs font-semibold text-muted-foreground uppercase",
							children: "Recent activity"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "max-h-64 divide-y divide-border overflow-y-auto",
							children: [workerTxns.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between gap-3 px-4 py-2.5 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: t.customerName
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block text-xs text-muted-foreground",
									children: [
										formatDateTime(t.createdAt),
										" · ",
										t.fuel
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-right",
									children: [formatCurrency(t.amount), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block text-xs text-teal",
										children: ["−", formatCurrency(t.discountAmount)]
									})]
								})]
							}, t.id)), workerTxns.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "px-4 py-6 text-center text-sm text-muted-foreground",
								children: "No transactions recorded."
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: selected.status }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setSelected(null),
							children: "Close"
						})]
					})
				] })
			})
		})
	] });
}
//#endregion
export { WorkersPage as component };
