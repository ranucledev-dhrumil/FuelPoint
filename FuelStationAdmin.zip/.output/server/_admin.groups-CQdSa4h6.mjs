import { i as __toESM } from "./_runtime.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { l as formatNumber, m as useAdmin, n as DEFAULT_GROUP_ID, o as formatCurrency, s as formatDate, u as groupDistribution } from "./_ssr/admin-store-DLYihnwj.mjs";
import { t as cn } from "./_ssr/utils-C_uf36nf.mjs";
import { R as BadgePercent, c as Tags, d as Power, f as Plus, p as Pencil, r as Users, s as Trash2 } from "./_libs/lucide-react.mjs";
import { i as StatCard, n as PageHeader, r as Panel } from "./_ssr/primitives-BY6eLzWO.mjs";
import { t as Button } from "./_ssr/button-Bq5vK6RO.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./_ssr/dialog-CwLzEEob.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./_ssr/select-Dg1urBTx.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { n as HorizontalBarChart, t as DonutChart } from "./_ssr/charts-CYjSJrBW.mjs";
import { n as Label, t as Input } from "./_ssr/label-B7oQAA24.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_admin.groups-CQdSa4h6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-[60px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Textarea.displayName = "Textarea";
var blank = {
	id: "",
	name: "",
	discountPercent: 1,
	description: "",
	active: true
};
function GroupsPage() {
	const { groups, customers, transactions, saveGroup, deleteGroup, toggleGroupActive, assignCustomerGroup } = useAdmin();
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [assignTarget, setAssignTarget] = (0, import_react.useState)(null);
	const [assignCustomer, setAssignCustomer] = (0, import_react.useState)("");
	const stats = (0, import_react.useMemo)(() => groupDistribution(customers, groups, transactions), [
		customers,
		groups,
		transactions
	]);
	const totalDiscount = stats.reduce((s, g) => s + g.discountGenerated, 0);
	const submit = () => {
		if (!editing) return;
		if (!editing.name.trim()) {
			toast.error("Group name is required.");
			return;
		}
		const id = editing.id || `grp-${editing.name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`;
		saveGroup({
			...editing,
			id,
			discountPercent: Number(editing.discountPercent) || 0
		});
		toast.success(editing.id ? "Group updated" : "Group created", { description: editing.name });
		setEditing(null);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Groups & Discounts",
			subtitle: "Define discount groups and control the percentage applied at scan time.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => setEditing({ ...blank }),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " New group"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Total groups",
					value: formatNumber(groups.length),
					icon: Tags
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Active groups",
					value: formatNumber(groups.filter((g) => g.active).length),
					icon: Power,
					tone: "teal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Grouped customers",
					value: formatNumber(customers.filter((c) => c.groupId !== DEFAULT_GROUP_ID).length),
					icon: Users,
					tone: "navy"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Discount generated",
					value: formatCurrency(totalDiscount),
					icon: BadgePercent,
					tone: "teal"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 space-y-4",
			children: stats.map((g) => {
				const group = groups.find((x) => x.id === g.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card p-5 transition-all duration-200 hover:shadow-elevated",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-base font-semibold text-foreground",
											children: g.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-semibold text-primary",
											children: [g.discountPercent, "% discount"]
										}),
										!g.active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full bg-muted px-2.5 py-0.5 text-xs font-medium text-muted-foreground",
											children: "Inactive"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1.5 max-w-2xl text-sm text-muted-foreground",
									children: group.description || "No description provided."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-xs text-muted-foreground",
									children: ["Created ", formatDate(group.createdAt)]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "sm",
									onClick: () => setAssignTarget(group),
									children: "Assign customers"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "icon",
									"aria-label": "Edit group",
									onClick: () => setEditing({
										id: group.id,
										name: group.name,
										discountPercent: group.discountPercent,
										description: group.description,
										active: group.active
									}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
								}),
								!group.isDefault && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "icon",
									"aria-label": "Toggle active",
									onClick: () => toggleGroupActive(group.id),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Power, { className: "size-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "icon",
									"aria-label": "Delete group",
									className: "text-destructive hover:bg-destructive/10 hover:text-destructive",
									onClick: () => {
										deleteGroup(group.id);
										toast.success("Group deleted", { description: `${group.name} customers moved to Default / Unassigned.` });
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
								})] })
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 grid grid-cols-3 gap-3 sm:gap-4",
						children: [
							["Customers", formatNumber(g.customers)],
							["Transactions", formatNumber(g.transactions)],
							["Discount generated", formatCurrency(g.discountGenerated)]
						].map(([l, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg bg-muted/40 p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: l
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm font-semibold text-foreground",
								children: v
							})]
						}, l))
					})]
				}, g.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold tracking-tight text-foreground",
					children: "Group analytics"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Customer distribution and discount generation across groups"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Customer distribution",
					description: "Share of registered customers across groups",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DonutChart, {
						data: stats.filter((g) => g.customers > 0).map((g) => ({
							name: g.name,
							value: g.customers
						})),
						height: 320
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Discount contribution",
					description: "Total discount generated per group",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HorizontalBarChart, {
						data: stats.slice().sort((a, b) => b.discountGenerated - a.discountGenerated).map((g) => ({
							name: g.name,
							discount: g.discountGenerated
						})),
						dataKey: "discount",
						height: 320,
						color: "var(--teal)",
						valueFormatter: formatCurrency,
						yAxisWidth: 110,
						showLabels: true
					})
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: !!editing,
			onOpenChange: (o) => !o && setEditing(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
				className: "sm:max-w-md",
				children: editing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: editing.id ? "Edit group" : "Create discount group" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "The discount percentage applies automatically to every scan for this group." })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "g-name",
									children: "Group name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "g-name",
									value: editing.name,
									onChange: (e) => setEditing({
										...editing,
										name: e.target.value
									}),
									placeholder: "e.g. Neighbours"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "g-pct",
									children: "Discount percentage"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "g-pct",
									type: "number",
									min: 0,
									max: 100,
									step: .5,
									value: editing.discountPercent,
									onChange: (e) => setEditing({
										...editing,
										discountPercent: Number(e.target.value)
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "g-desc",
									children: "Description"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									id: "g-desc",
									value: editing.description,
									onChange: (e) => setEditing({
										...editing,
										description: e.target.value
									}),
									placeholder: "Who belongs in this group?"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => setEditing(null),
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: submit,
						children: editing.id ? "Save changes" : "Create group"
					})] })
				] })
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: !!assignTarget,
			onOpenChange: (o) => !o && setAssignTarget(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
				className: "sm:max-w-md",
				children: assignTarget && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Assign customer to ", assignTarget.name] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Unassigned customers are listed first — they are waiting for a group." })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: assignCustomer,
						onValueChange: setAssignCustomer,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select a customer" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, {
							className: "max-h-72",
							children: [...customers].filter((c) => c.groupId !== assignTarget.id).sort((a, b) => a.groupId === "grp-default" ? -1 : b.groupId === "grp-default" ? 1 : 0).slice(0, 60).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
								value: c.id,
								children: [
									c.name,
									" · ",
									c.phone
								]
							}, c.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => setAssignTarget(null),
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: !assignCustomer,
						onClick: () => {
							assignCustomerGroup(assignCustomer, assignTarget.id);
							toast.success("Customer assigned", { description: assignTarget.name });
							setAssignCustomer("");
							setAssignTarget(null);
						},
						children: "Assign"
					})] })
				] })
			})
		})
	] });
}
//#endregion
export { GroupsPage as component };
