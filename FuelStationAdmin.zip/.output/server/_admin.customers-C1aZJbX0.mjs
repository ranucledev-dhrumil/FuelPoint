import { i as __toESM } from "./_runtime.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { a as exportCsv, c as formatDateTime, l as formatNumber, m as useAdmin, o as formatCurrency, p as relativeDays, r as buildOverview, s as formatDate } from "./_ssr/admin-store-DLYihnwj.mjs";
import { a as UserCheck, i as UserPlus, r as Users, u as Search, x as Fuel } from "./_libs/lucide-react.mjs";
import { t as DataTable } from "./_ssr/DataTable-C6ZgHd1t.mjs";
import { a as StatusBadge, i as StatCard, n as PageHeader, r as Panel, t as GroupPill } from "./_ssr/primitives-BY6eLzWO.mjs";
import { t as Button } from "./_ssr/button-Bq5vK6RO.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./_ssr/dialog-CwLzEEob.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./_ssr/select-Dg1urBTx.mjs";
import { n as toast } from "./_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_admin.customers-C1aZJbX0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CustomersPage() {
	const { customers, groups, transactions, workers, assignCustomerGroup } = useAdmin();
	const [query, setQuery] = (0, import_react.useState)("");
	const [groupFilter, setGroupFilter] = (0, import_react.useState)("all");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("all");
	const [selectedId, setSelectedId] = (0, import_react.useState)(null);
	const overview = (0, import_react.useMemo)(() => buildOverview(customers, workers, groups, transactions), [
		customers,
		workers,
		groups,
		transactions
	]);
	const groupName = (id) => groups.find((g) => g.id === id)?.name ?? "Unassigned";
	const groupPercent = (id) => groups.find((g) => g.id === id)?.discountPercent ?? 0;
	const filtered = (0, import_react.useMemo)(() => customers.filter((c) => (groupFilter === "all" || c.groupId === groupFilter) && (statusFilter === "all" || c.status === statusFilter) && (c.name.toLowerCase().includes(query.toLowerCase()) || c.phone.includes(query) || c.id.toLowerCase().includes(query.toLowerCase()))), [
		customers,
		query,
		groupFilter,
		statusFilter
	]);
	const selected = customers.find((c) => c.id === selectedId) ?? null;
	const selectedTxns = selected ? transactions.filter((t) => t.customerId === selected.id).slice(0, 8) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Customers",
			subtitle: "Registrations, group assignment and fuelling history.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => exportCsv("customers.csv", filtered.map((c) => ({
					ID: c.id,
					Name: c.name,
					Phone: c.phone,
					Group: groupName(c.groupId),
					Registered: formatDate(c.registeredAt),
					Transactions: c.transactions,
					Discount: c.discountReceived,
					Status: c.status
				}))),
				children: "Export CSV"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Total customers",
					value: formatNumber(overview.totalCustomers),
					icon: Users
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "New registrations",
					value: formatNumber(overview.newRegistrations7d),
					icon: UserPlus,
					tone: "warning",
					hint: "last 7 days"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Active customers",
					value: formatNumber(overview.activeCustomers),
					icon: UserCheck,
					tone: "teal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Used the pump",
					value: formatNumber(overview.usedPumpCustomers),
					icon: Fuel,
					tone: "navy",
					hint: `${overview.unassignedCustomers} awaiting group`
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			title: "Customer directory",
			description: "Click a row to open the customer profile and activity",
			className: "mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-56 flex-1 items-center gap-2 rounded-lg border border-border px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: query,
							onChange: (e) => setQuery(e.target.value),
							placeholder: "Search by name, phone or customer ID",
							className: "w-full bg-transparent text-sm outline-none"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: groupFilter,
						onValueChange: setGroupFilter,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "w-48",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "all",
							children: "All groups"
						}), groups.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: g.id,
							children: g.name
						}, g.id))] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: statusFilter,
						onValueChange: setStatusFilter,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "w-40",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "all",
								children: "All statuses"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "active",
								children: "Active"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "pending",
								children: "Pending"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "inactive",
								children: "Inactive"
							})
						] })]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				rows: filtered,
				columns: [
					{
						key: "name",
						header: "Customer",
						sortValue: (c) => c.name,
						render: (c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium text-foreground",
							children: c.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								c.phone,
								" · ",
								c.id
							]
						})] })
					},
					{
						key: "group",
						header: "Group",
						sortValue: (c) => groupName(c.groupId),
						render: (c) => c.groupId === "grp-default" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "inline-flex items-center rounded-full bg-warning/18 px-2.5 py-1 text-xs font-semibold text-warning-foreground",
							children: "Unassigned"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GroupPill, {
							name: groupName(c.groupId),
							percent: groupPercent(c.groupId)
						})
					},
					{
						key: "registered",
						header: "Registered",
						sortValue: (c) => c.registeredAt,
						render: (c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: formatDate(c.registeredAt)
						})
					},
					{
						key: "status",
						header: "Status",
						sortValue: (c) => c.status,
						render: (c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: c.status })
					},
					{
						key: "txns",
						header: "Transactions",
						align: "right",
						sortValue: (c) => c.transactions,
						render: (c) => formatNumber(c.transactions)
					},
					{
						key: "discount",
						header: "Discount received",
						align: "right",
						sortValue: (c) => c.discountReceived,
						render: (c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium text-teal",
							children: formatCurrency(c.discountReceived)
						})
					},
					{
						key: "last",
						header: "Last activity",
						align: "right",
						sortValue: (c) => c.lastActivity ?? "",
						render: (c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: relativeDays(c.lastActivity)
						})
					}
				],
				pageSize: 10,
				onRowClick: (c) => setSelectedId(c.id)
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: !!selected,
			onOpenChange: (o) => !o && setSelectedId(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
				className: "sm:max-w-xl",
				children: selected && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: selected.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
						selected.id,
						" · ",
						selected.phone,
						" · ",
						selected.vehicle
					] })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-3 sm:grid-cols-4",
						children: [
							["Registered", formatDate(selected.registeredAt)],
							["Transactions", formatNumber(selected.transactions)],
							["Total spend", formatCurrency(selected.totalSpend)],
							["Discount", formatCurrency(selected.discountReceived)]
						].map(([l, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-border bg-muted/40 p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: l
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm font-semibold text-foreground",
								children: v
							})]
						}, l))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-border p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold text-muted-foreground uppercase",
							children: "Discount group"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: selected.groupId,
								onValueChange: (v) => {
									assignCustomerGroup(selected.id, v);
									toast.success("Group updated", { description: `${selected.name} moved to ${groupName(v)}.` });
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									className: "w-60",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: groups.filter((g) => g.active || g.id === selected.groupId).map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
									value: g.id,
									children: [
										g.name,
										" — ",
										g.discountPercent,
										"%"
									]
								}, g.id)) })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: selected.status })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-border",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "border-b border-border px-4 py-2.5 text-xs font-semibold text-muted-foreground uppercase",
							children: "Recent activity"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "max-h-56 divide-y divide-border overflow-y-auto",
							children: [selectedTxns.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between px-4 py-2.5 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									t.fuel,
									" · ",
									t.litres,
									" L",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block text-xs text-muted-foreground",
										children: [
											formatDateTime(t.createdAt),
											" · ",
											t.workerName
										]
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-right",
									children: [formatCurrency(t.amount), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block text-xs text-teal",
										children: ["−", formatCurrency(t.discountAmount)]
									})]
								})]
							}, t.id)), selectedTxns.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "px-4 py-6 text-center text-sm text-muted-foreground",
								children: "This customer hasn't fuelled yet."
							})]
						})]
					})
				] })
			})
		})
	] });
}
//#endregion
export { CustomersPage as component };
