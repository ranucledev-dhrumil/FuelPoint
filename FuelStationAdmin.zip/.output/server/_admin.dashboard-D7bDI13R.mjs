import { i as __toESM } from "./_runtime.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { c as formatDateTime, h as workerActivity, i as buildSeries, l as formatNumber, m as useAdmin, o as formatCurrency, r as buildOverview, u as groupDistribution } from "./_ssr/admin-store-DLYihnwj.mjs";
import { g as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { F as CalendarClock, H as Activity, R as BadgePercent, c as Tags, i as UserPlus, n as Wrench, o as TrendingUp, r as Users } from "./_libs/lucide-react.mjs";
import { i as StatCard, n as PageHeader, r as Panel } from "./_ssr/primitives-BY6eLzWO.mjs";
import { t as Button } from "./_ssr/button-Bq5vK6RO.mjs";
import { i as TrendAreaChart, n as HorizontalBarChart, r as MultiLineChart, t as DonutChart } from "./_ssr/charts-CYjSJrBW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_admin.dashboard-D7bDI13R.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ranges = [
	{
		key: 7,
		label: "7 days"
	},
	{
		key: 30,
		label: "30 days"
	},
	{
		key: 90,
		label: "90 days"
	}
];
function DashboardPage() {
	const { customers, workers, groups, transactions } = useAdmin();
	const [days, setDays] = (0, import_react.useState)(30);
	const overview = (0, import_react.useMemo)(() => buildOverview(customers, workers, groups, transactions), [
		customers,
		workers,
		groups,
		transactions
	]);
	const series = (0, import_react.useMemo)(() => buildSeries(customers, transactions, days), [
		customers,
		transactions,
		days
	]);
	const dist = (0, import_react.useMemo)(() => groupDistribution(customers, groups, transactions).filter((g) => g.customers > 0), [
		customers,
		groups,
		transactions
	]);
	const activity = (0, import_react.useMemo)(() => workerActivity(workers).slice(0, 8), [workers]);
	const recent = transactions.slice(0, 8);
	const half = Math.floor(series.length / 2);
	const delta = (key) => {
		const first = series.slice(0, half).reduce((s, p) => s + p[key], 0);
		const second = series.slice(half).reduce((s, p) => s + p[key], 0);
		if (!first) return 0;
		return (second - first) / first * 100;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Dashboard",
			subtitle: "Performance of scans, discounts and customer growth across your pump network.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center gap-1 rounded-lg border border-border bg-card p-1",
				children: ranges.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setDays(r.key),
					className: days === r.key ? "rounded-md bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground" : "rounded-md px-3 py-1.5 text-xs font-medium text-muted-foreground hover:bg-muted",
					children: r.label
				}, r.key))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Total customers",
					value: formatNumber(overview.totalCustomers),
					icon: Users,
					delta: delta("registrations"),
					hint: "vs previous period"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Total workers",
					value: formatNumber(overview.totalWorkers),
					icon: Wrench,
					tone: "teal",
					hint: `${overview.activeWorkers} active now`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Discount groups",
					value: formatNumber(overview.totalGroups),
					icon: Tags,
					tone: "navy",
					hint: `${overview.unassignedCustomers} unassigned customers`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Total scans",
					value: formatNumber(overview.totalTransactions),
					icon: Activity,
					delta: delta("transactions"),
					hint: "transactions processed"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Total discount given",
					value: formatCurrency(overview.totalDiscount),
					icon: BadgePercent,
					tone: "teal",
					delta: delta("discount"),
					hint: `avg ${overview.avgDiscountPercent.toFixed(2)}% of sales`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Today's transactions",
					value: formatNumber(overview.todayTransactions),
					icon: CalendarClock,
					hint: `${formatCurrency(overview.todayDiscount)} discount today`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "New registrations",
					value: formatNumber(overview.newRegistrations7d),
					icon: UserPlus,
					tone: "warning",
					hint: "last 7 days"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Customers who fuelled",
					value: formatNumber(overview.usedPumpCustomers),
					icon: TrendingUp,
					tone: "navy",
					hint: `${overview.activeCustomers} active customers`
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 space-y-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-6 lg:grid-cols-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "Transactions & scans over time",
						description: `Daily scan volume for the last ${days} days`,
						className: "lg:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendAreaChart, {
							data: series,
							dataKey: "transactions",
							height: 280
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "Group-wise customers",
						description: "Distribution across discount groups",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DonutChart, {
							data: dist.map((g) => ({
								name: g.name,
								value: g.customers
							})),
							height: 280
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-6 lg:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "Discount given over time",
						description: "Rupees discounted per day",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendAreaChart, {
							data: series,
							dataKey: "discount",
							color: "var(--teal)",
							height: 280,
							valueFormatter: formatCurrency
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "Registrations vs scans",
						description: "Customer growth against usage",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MultiLineChart, {
							data: series,
							height: 280,
							series: [{
								key: "registrations",
								name: "Registrations",
								color: "var(--chart-4)"
							}, {
								key: "transactions",
								name: "Scans",
								color: "var(--primary)"
							}]
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-6 lg:grid-cols-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "Worker scanning activity",
						description: "Top performers by scans",
						className: "lg:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HorizontalBarChart, {
							data: activity,
							dataKey: "scans",
							height: 320,
							color: "var(--primary)"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "Recent transactions",
						description: "Latest scans processed at the pump",
						className: "lg:col-span-3",
						actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							size: "sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/reports",
								children: "View reports"
							})
						}),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "divide-y divide-border/70",
							children: recent.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-3 py-3 px-1 transition-colors hover:bg-muted/30 first:pt-1 last:pb-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex size-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-xs font-semibold text-primary",
										children: t.customerName.split(" ").map((n) => n[0]).join("")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-sm font-medium text-foreground",
											children: t.customerName
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "truncate text-xs text-muted-foreground",
											children: [
												t.fuel,
												" · ",
												t.litres,
												" L · scanned by ",
												t.workerName
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-right",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-semibold text-foreground",
											children: formatCurrency(t.amount)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs font-medium text-teal",
											children: [
												"−",
												formatCurrency(t.discountAmount),
												" (",
												t.discountPercent,
												"%)"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "hidden w-28 text-right text-xs text-muted-foreground sm:block",
										children: formatDateTime(t.createdAt)
									})
								]
							}, t.id))
						})
					})]
				})
			]
		})
	] });
}
//#endregion
export { DashboardPage as component };
