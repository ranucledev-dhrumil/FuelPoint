import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-[#14C7A3] text-[#6D6E71] rounded-[20px] shadow hover:bg-[#14C7A3]/90 font-bold",
        destructive: "bg-destructive text-destructive-foreground rounded-[20px] shadow-sm hover:bg-destructive/90",
        outline: "border border-[#E5E7EB] bg-transparent rounded-[8px] text-[#6D6E71] shadow-sm hover:bg-[#F5F7FA]",
        secondary: "bg-transparent border border-[#6D6E71] rounded-[4px] text-[#6D6E71] shadow-sm hover:bg-[#F5F7FA]",
        ghost: "hover:bg-[#F5F7FA] hover:text-[#14C7A3] rounded-[8px]",
        link: "text-[#6D6E71] underline-offset-4 hover:underline rounded-none p-0",
      },
      size: {
        default: "h-9 px-4 py-2",
        sm: "h-8 rounded-[4px] px-3 text-xs",
        lg: "h-10 rounded-[20px] px-8",
        icon: "h-9 w-9 rounded-[8px]",
        nayara: "h-[68px] w-[232px] px-[34px] py-[23px] text-[21px] rounded-[20px]"
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />
    );
  },
);
Button.displayName = "Button";

export { Button, buttonVariants };
